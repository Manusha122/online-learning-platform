import React, { useState } from "react";
import "../styles/EnrollmentForm.css";

const EnrollmentForm = ({ onSubmit }) => {
  const [studentId, setStudentId] = useState("");
  const [courseId, setCourseId] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit({ studentId, courseId });
  };

  return (
    <form onSubmit={handleSubmit} className="enrollment-form">
      <h2 className="form-title">Course Enrollment</h2>
      <div className="form-group">
        <label className="form-label">Student ID</label>
        <input
          type="text"
          value={studentId}
          onChange={(e) => setStudentId(e.target.value)}
          className="form-input"
          placeholder="Enter your student ID"
          required
        />
      </div>
      <div className="form-group">
        <label className="form-label">Course ID</label>
        <input
          type="text"
          value={courseId}
          onChange={(e) => setCourseId(e.target.value)}
          className="form-input"
          placeholder="Enter course ID"
          required
        />
      </div>
      <button 
        type="submit" 
        className="submit-button"
      >
        <span>Enroll Now</span>
        <svg xmlns="http://www.w3.org/2000/svg" className="button-icon" viewBox="0 0 20 20" fill="currentColor">
          <path fillRule="evenodd" d="M10.293 5.293a1 1 0 011.414 0l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414-1.414L12.586 11H5a1 1 0 110-2h7.586l-2.293-2.293a1 1 0 010-1.414z" clipRule="evenodd" />
        </svg>
      </button>
    </form>
  );
};

export default EnrollmentForm;