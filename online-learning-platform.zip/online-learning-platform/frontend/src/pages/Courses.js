import React, { useEffect, useState } from "react";
import Navbar from "../components/Navbar";
import CourseCard from "../components/CourseCard";

const Courses = () => {
  const [courses, setCourses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [category, setCategory] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");

  useEffect(() => {
    // Fetch courses from API
    const fetchCourses = async () => {
      try {
        const response = await fetch("http://localhost:5000/api/courses");
        const data = await response.json();
        setCourses(data);
        setLoading(false);
      } catch (error) {
        console.error("Error fetching courses:", error);
        setLoading(false);
      }
    };
    fetchCourses();
  }, []);

  // Filter courses based on category and search query
  const filteredCourses = courses.filter(course => {
    const matchesCategory = category === "all" || course.category === category;
    const matchesSearch = course.title.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  // Skeleton loader during API fetch
  const SkeletonLoader = () => (
    <>
      {[1, 2, 3, 4, 5, 6].map(i => (
        <div key={i} className="card shadow-sm border placeholder-glow">
          <div className="bg-secondary placeholder col-12" style={{height: "12rem"}}></div>
          <div className="card-body">
            <div className="placeholder col-9 mb-3"></div>
            <div className="placeholder col-12 mb-2"></div>
            <div className="placeholder col-10 mb-3"></div>
            <div className="placeholder col-4 mt-3"></div>
          </div>
        </div>
      ))}
    </>
  );

  return (
    <div className="min-vh-100 bg-light">
      <Navbar />
      <div className="container py-4">
        <div className="row mb-4 align-items-center">
          <div className="col-md-6 mb-3 mb-md-0">
            <h1 className="display-5 fw-bold">Explore Courses</h1>
          </div>
          <div className="col-md-6">
            <div className="position-relative">
              <input
                type="text"
                className="form-control ps-5"
                placeholder="Search courses..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <svg className="position-absolute top-50 start-0 translate-middle-y ms-3 text-secondary" width="20" height="20" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z" clipRule="evenodd" />
              </svg>
            </div>
          </div>
        </div>
        
        <div className="d-flex overflow-auto pb-3 mb-4" style={{scrollbarWidth: "none", msOverflowStyle: "none"}}>
          <button 
            className={`btn me-2 rounded-pill ${
              category === "all" ? "btn-primary" : "btn-outline-secondary"
            }`}
            onClick={() => setCategory("all")}
          >
            All Courses
          </button>
          <button 
            className={`btn me-2 rounded-pill ${
              category === "programming" ? "btn-primary" : "btn-outline-secondary"
            }`}
            onClick={() => setCategory("programming")}
          >
            Programming
          </button>
          <button 
            className={`btn me-2 rounded-pill ${
              category === "design" ? "btn-primary" : "btn-outline-secondary"
            }`}
            onClick={() => setCategory("design")}
          >
            Design
          </button>
          <button 
            className={`btn me-2 rounded-pill ${
              category === "business" ? "btn-primary" : "btn-outline-secondary"
            }`}
            onClick={() => setCategory("business")}
          >
            Business
          </button>
          <button 
            className={`btn me-2 rounded-pill ${
              category === "marketing" ? "btn-primary" : "btn-outline-secondary"
            }`}
            onClick={() => setCategory("marketing")}
          >
            Marketing
          </button>
        </div>

        {loading ? (
          <div className="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
            <SkeletonLoader />
          </div>
        ) : filteredCourses.length > 0 ? (
          <div className="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
            {filteredCourses.map((course) => (
              <div className="col" key={course.id}>
                <CourseCard course={course} />
              </div>
            ))}
          </div>
        ) : (
          <div className="card p-5 text-center">
            <div className="card-body">
              <svg className="mx-auto mb-3 text-secondary" width="64" height="64" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
              </svg>
              <h3 className="h5 mb-2">No courses found</h3>
              <p className="text-secondary">Try adjusting your search or filter to find what you're looking for.</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Courses;