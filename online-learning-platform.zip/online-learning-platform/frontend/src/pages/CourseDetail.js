import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import Navbar from "../components/Navbar";

const CourseDetail = () => {
  const { id } = useParams();
  const [course, setCourse] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Fetch course details from API
    const fetchCourse = async () => {
      try {
        const response = await fetch(`http://localhost:5000/api/courses/${id}`);
        const data = await response.json();
        setCourse(data);
        setLoading(false);
      } catch (error) {
        console.error("Error fetching course:", error);
        setLoading(false);
      }
    };
    fetchCourse();
  }, [id]);

  if (loading) {
    return (
      <div>
        <Navbar />
        <div className="container d-flex justify-content-center align-items-center min-vh-100 p-4">
          <div className="d-flex flex-column align-items-center placeholder-glow">
            <div className="placeholder col-6 mb-3 bg-secondary" style={{height: "2rem"}}></div>
            <div className="placeholder col-12 mb-2 bg-secondary" style={{height: "1rem"}}></div>
            <div className="placeholder col-12 mb-2 bg-secondary" style={{height: "1rem"}}></div>
            <div className="placeholder col-9 bg-secondary" style={{height: "1rem"}}></div>
          </div>
        </div>
      </div>
    );
  }

  if (!course) {
    return (
      <div>
        <Navbar />
        <div className="container d-flex justify-content-center align-items-center p-5">
          <div className="alert alert-danger">
            Course not found or error loading course data.
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-vh-100 bg-light">
      <Navbar />
      <div className="container py-4">
        <div className="card shadow-sm overflow-hidden">
          <div className="position-relative" style={{height: "12rem", background: "linear-gradient(to right, #0d6efd, #4da1ff)"}}>
            <div className="position-absolute top-0 start-0 w-100 h-100 bg-dark opacity-25"></div>
            <div className="position-absolute bottom-0 start-0 p-4">
              <span className="badge bg-light text-primary mb-2 rounded-pill">
                {course.category || "Course"}
              </span>
              <h1 className="display-6 fw-bold text-white">{course.title}</h1>
            </div>
          </div>
          
          <div className="p-4">
            <div className="d-flex flex-wrap align-items-center mb-4 text-secondary">
              <div className="d-flex align-items-center me-4 mb-2">
                <svg className="me-2" width="20" height="20" fill="currentColor" viewBox="0 0 20 20">
                  <path d="M10 18a8 8 0 100-16 8 8 0 000 16zm0-2a6 6 0 110-12 6 6 0 010 12z" />
                  <path d="M10 6a1 1 0 011 1v3.586l2.293-2.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 111.414-1.414L9 10.586V7a1 1 0 011-1z" />
                </svg>
                <span>{course.duration || "8 weeks"}</span>
              </div>
              <div className="d-flex align-items-center me-4 mb-2">
                <svg className="me-2" width="20" height="20" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z" clipRule="evenodd" />
                </svg>
                <span>{course.level || "Intermediate"}</span>
              </div>
              <div className="d-flex align-items-center mb-2">
                <svg className="me-2" width="20" height="20" fill="currentColor" viewBox="0 0 20 20">
                  <path d="M9 6a3 3 0 11-6 0 3 3 0 016 0zM17 6a3 3 0 11-6 0 3 3 0 016 0zM13 14a3 3 0 11-6 0 3 3 0 016 0zM5 14a3 3 0 11-6 0 3 3 0 016 0z" />
                </svg>
                <span>{course.students || "124"} students</span>
              </div>
            </div>

            <h2 className="h4 fw-semibold mb-3">Course Overview</h2>
            <p className="text-secondary mb-4">{course.description}</p>

            <div className="d-flex flex-column flex-sm-row gap-3 mt-4">
              <button className="btn btn-primary px-4 py-2">
                Enroll Now
              </button>
              <button className="btn btn-outline-secondary px-4 py-2">
                Download Syllabus
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CourseDetail;