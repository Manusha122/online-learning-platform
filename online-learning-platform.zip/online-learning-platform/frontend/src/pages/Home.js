import React from "react";
import Navbar from "../components/Navbar";
import "../styles/home.css";
import image1 from "../img/image1.jpg"; 
import image2 from "../img/image2.jpg";
import image3 from "../img/image3.jpg";
import image4 from "../img/image4.png";

const Home = () => {
  const featuredCourses = [
    { id: 1, title: "Introduction to Web Development", category: "Development", lessons: 24, level: "Beginner", image: image2 },
    { id: 2, title: "Advanced React Patterns", category: "Framework", lessons: 18, level: "Advanced", image: image4 },
    { id: 3, title: "UX/UI Design Fundamentals", category: "Design", lessons: 16, level: "Intermediate", image:image3 },
  ];

  return (
    <div className="min-h-screen bg-gradient">
      <Navbar />
      
      {/* Hero Section */}
      <div className="hero-section">
        <div className="container">
          <div className="hero-grid">
            <div className="hero-content">
              <h1 className="hero-title">
                Unlock Your Potential With Online Learning
              </h1>
              <p className="hero-text">
                Access thousands of expert-led courses and transform your skills from anywhere, at any time.
              </p>
              <div className="button-group">
                <button className="btn btn-primary">
                  Explore Courses
                </button>
                <button className="btn btn-outline">
                  Sign Up Free
                </button>
              </div>
            </div>
            <div className="hero-image-container">
            <div className="hero-image-wrapper">
               <img src={image1} alt="Student learning online" className="hero-image" />
              </div>
              <div className="discount-badge">
                <span className="discount-text">50% OFF</span>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Stats Section */}
      <div className="container">
        <div className="stats-grid">
          <div className="stat-card">
            <p className="stat-number">10k+</p>
            <p className="stat-label">Courses</p>
          </div>
          <div className="stat-card">
            <p className="stat-number">250+</p>
            <p className="stat-label">Instructors</p>
          </div>
          <div className="stat-card">
            <p className="stat-number">15M+</p>
            <p className="stat-label">Students</p>
          </div>
          <div className="stat-card">
            <p className="stat-number">4.8</p>
            <p className="stat-label">Avg. Rating</p>
          </div>
        </div>
      </div>
      
      {/* Featured Courses */}
      <div className="container">
        <div className="section-header">
          <h2 className="section-title">Featured Courses</h2>
          <p className="section-subtitle">Handpicked courses to get you started</p>
        </div>
        
        <div className="courses-grid">
          {featuredCourses.map((course) => (
            <div key={course.id} className="course-card">
              <div className="course-image-container">
                <img src={course.image} alt={course.title} className="course-image" />
                <div className="course-category">
                  {course.category}
                </div>
              </div>
              <div className="course-content">
                <h3 className="course-title">{course.title}</h3>
                <div className="course-meta">
                  <span>{course.lessons} lessons</span>
                  <span className="course-level">{course.level}</span>
                </div>
                <div className="course-footer">
                  <div className="instructor">
                    <div className="instructor-avatar"></div>
                    <span className="instructor-name">John Doe</span>
                  </div>
                  <button className="btn-link">View Course</button>
                </div>
              </div>
            </div>
          ))}
        </div>
        
        <div className="text-center margin-top">
          <button className="btn btn-primary">
            View All Courses
          </button>
        </div>
      </div>
      
      {/* Categories Section */}
      <div className="container">
        <div className="section-header">
          <h2 className="section-title">Browse Categories</h2>
          <p className="section-subtitle">Find the perfect course from our diverse catalog</p>
        </div>
        
        <div className="categories-grid">
          {['Development', 'Business', 'Design', 'Marketing', 'Photography', 'Music'].map((category) => (
            <div key={category} className="category-card">
              <div className="category-icon">
                <span className="icon">📚</span>
              </div>
              <p className="category-name">{category}</p>
              <p className="category-count">120+ Courses</p>
            </div>
          ))}
        </div>
      </div>
      
      {/* Testimonial Section */}
      <div className="testimonial-section">
        <div className="container">
          <div className="section-header">
            <h2 className="section-title">What Our Students Say</h2>
          </div>
          
          <div className="testimonial-card">
            <div className="testimonial-content">
              <div className="testimonial-avatar">
                <img src="/api/placeholder/200/200" alt="Student" className="avatar-image" />
              </div>
              <div className="testimonial-text">
                <div className="rating">
                  {'★★★★★'.split('').map((star, i) => (
                    <span key={i}>{star}</span>
                  ))}
                </div>
                <p className="quote">
                  "This platform completely transformed my career. The courses are well-structured, easy to follow, and taught by industry experts. I went from a complete beginner to landing my dream job in just 6 months!"
                </p>
                <p className="author-name">Sahan silva</p>
                <p className="author-title">Web Developer at Tech Co.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* CTA Section */}
      <div className="container">
        <div className="cta-section">
          <h2 className="cta-title">Ready to Start Learning?</h2>
          <p className="cta-text">
            Join millions of students and start transforming your skills today with our premium courses.
          </p>
          <div className="cta-buttons">
            <button className="btn btn-light">
              Sign Up Now
            </button>
            <button className="btn btn-outline-light">
              Explore Courses
            </button>
          </div>
        </div>
      </div>
      
      {/* Footer */}
      <footer className="footer">
        <div className="container">
          <div className="footer-grid">
            <div className="footer-col">
              <h3 className="footer-title">EduPlatform</h3>
              <p className="footer-text">
                The ultimate destination for online learning and skill development.
              </p>
            </div>
            <div className="footer-col">
              <h4 className="footer-heading">Quick Links</h4>
              <ul className="footer-links">
                <li><a href="#" className="footer-link">Home</a></li>
                <li><a href="#" className="footer-link">Courses</a></li>
                <li><a href="#" className="footer-link">About Us</a></li>
                <li><a href="#" className="footer-link">Contact</a></li>
              </ul>
            </div>
            <div className="footer-col">
              <h4 className="footer-heading">Categories</h4>
              <ul className="footer-links">
                <li><a href="#" className="footer-link">Development</a></li>
                <li><a href="#" className="footer-link">Business</a></li>
                <li><a href="#" className="footer-link">Design</a></li>
                <li><a href="#" className="footer-link">Marketing</a></li>
              </ul>
            </div>
            <div className="footer-col">
              <h4 className="footer-heading">Stay Connected</h4>
              <div className="social-links">
                <a href="#" className="social-link">
                  <span>FB</span>
                </a>
                <a href="#" className="social-link">
                  <span>TW</span>
                </a>
                <a href="#" className="social-link">
                  <span>IG</span>
                </a>
                <a href="#" className="social-link">
                  <span>LI</span>
                </a>
              </div>
              <p className="footer-text">Subscribe to our newsletter</p>
              <div className="newsletter-form">
                <input 
                  type="email" 
                  placeholder="Your email" 
                  className="newsletter-input"
                />
                <button className="newsletter-button">
                  Send
                </button>
              </div>
            </div>
          </div>
          <div className="footer-bottom">
            <p>&copy; 2025 EduPlatform. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Home;