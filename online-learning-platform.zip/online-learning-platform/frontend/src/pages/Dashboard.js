import React from "react";
import Navbar from "../components/Navbar";

const Dashboard = () => {
  // Sample data for stats cards
  const stats = [
    { title: "Total Users", value: "2,542", change: "+12.3%", trend: "up" },
    { title: "Revenue", value: "$8,294", change: "+5.4%", trend: "up" },
    { title: "Conversion", value: "3.6%", change: "-2.1%", trend: "down" },
    { title: "Active Sessions", value: "149", change: "+24.5%", trend: "up" },
  ];

  // Sample data for recent activity
  const activities = [
    { user: "Sarah Johnson", action: "Completed onboarding", time: "2 minutes ago" },
    { user: "Mike Davis", action: "Purchased Premium Plan", time: "1 hour ago" },
    { user: "Lisa Wang", action: "Submitted support ticket", time: "3 hours ago" },
    { user: "Tom Wilson", action: "Updated profile", time: "5 hours ago" },
  ];

  return (
    <div className="min-vh-100 bg-light">
      <Navbar />
      <div className="container p-4">
        {/* Header section */}
        <div className="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center mb-4">
          <div>
            <h1 className="display-5 fw-bold">Dashboard</h1>
            <p className="text-secondary mt-1">Welcome back! Here's what's happening today.</p>
          </div>
          <button className="mt-3 mt-md-0 btn btn-primary shadow">
            Generate Report
          </button>
        </div>

        {/* Stats cards */}
        <div className="row row-cols-1 row-cols-md-2 row-cols-lg-4 g-4 mb-4">
          {stats.map((stat, index) => (
            <div key={index} className="col">
              <div className="card shadow-sm border h-100 p-3">
                <div className="d-flex justify-content-between align-items-center">
                  <h2 className="text-secondary fw-medium fs-6">{stat.title}</h2>
                  <span className={`badge ${
                    stat.trend === "up" ? "bg-success bg-opacity-25 text-success" : "bg-danger bg-opacity-25 text-danger"
                  }`}>
                    {stat.change}
                  </span>
                </div>
                <p className="fs-3 fw-bold mt-2">{stat.value}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Main content grid */}
        <div className="row g-4">
          {/* Chart section */}
          <div className="col-lg-8">
            <div className="card shadow-sm border p-4 h-100">
              <h2 className="fs-4 fw-bold mb-3">Performance Overview</h2>
              <div className="bg-light rounded p-5 d-flex align-items-center justify-content-center" style={{height: "16rem"}}>
                <p className="text-secondary">Chart visualization would render here</p>
              </div>
            </div>
          </div>

          {/* Recent activity */}
          <div className="col-lg-4">
            <div className="card shadow-sm border p-4 h-100">
              <h2 className="fs-4 fw-bold mb-3">Recent Activity</h2>
              <div>
                {activities.map((activity, index) => (
                  <div key={index} className="border-bottom pb-3 mb-3">
                    <p className="fw-medium">{activity.user}</p>
                    <p className="text-secondary small">{activity.action}</p>
                    <p className="text-muted smaller mt-1">{activity.time}</p>
                  </div>
                ))}
              </div>
              <button className="btn btn-link text-primary p-0 mt-2 text-decoration-none">
                View All Activity
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;