import React, { useState } from "react";
import Navbar from "../components/Navbar";
import StudentForm from "../components/StudentForm";
import EnrollmentForm from "../components/EnrollmentForm";

const Admin = () => {
  const [students, setStudents] = useState([]);
  const [enrollments, setEnrollments] = useState([]);
  const [activeTab, setActiveTab] = useState("students");

  const handleAddStudent = (student) => {
    // Call API to add student
    setStudents([...students, student]);
  };

  const handleEnrollStudent = (enrollment) => {
    // Call API to enroll student
    setEnrollments([...enrollments, enrollment]);
  };

  return (
    <div className="min-vh-100 bg-light">
      <Navbar />
      <div className="container py-4">
        <div className="d-flex align-items-center justify-content-between mb-4">
          <h1 className="h2 fw-bold">Admin Dashboard</h1>
          <div className="d-flex gap-2">
            <button className="btn btn-primary">
              Export Data
            </button>
            <button className="btn btn-outline-secondary">
              Settings
            </button>
          </div>
        </div>

        {/* Tabs */}
        <div className="mb-4 border-bottom">
          <nav className="nav nav-tabs border-bottom-0">
            <button
              onClick={() => setActiveTab("students")}
              className={`nav-link ${activeTab === "students" ? "active" : ""}`}
            >
              Student Management
            </button>
            <button
              onClick={() => setActiveTab("enrollments")}
              className={`nav-link ${activeTab === "enrollments" ? "active" : ""}`}
            >
              Enrollment Management
            </button>
          </nav>
        </div>

        <div className="row g-4">
          {activeTab === "students" && (
            <div className="col-md-6">
              <div className="card">
                <div className="card-body">
                  <h2 className="card-title h5 mb-3">Add New Student</h2>
                  <StudentForm onSubmit={handleAddStudent} />
                </div>
              </div>
            </div>
          )}
          
          {activeTab === "enrollments" && (
            <div className="col-md-6">
              <div className="card">
                <div className="card-body">
                  <h2 className="card-title h5 mb-3">Enroll Student in Course</h2>
                  <EnrollmentForm onSubmit={handleEnrollStudent} />
                </div>
              </div>
            </div>
          )}
          
          <div className="col-md-6">
            <div className="card">
              <div className="card-body">
                <h2 className="card-title h5 mb-3">
                  {activeTab === "students" ? "Recent Students" : "Recent Enrollments"}
                </h2>
                <div className="table-responsive">
                  <table className="table table-bordered table-hover">
                    <thead className="table-light">
                      <tr>
                        {activeTab === "students" ? (
                          <>
                            <th className="text-start">Name</th>
                            <th className="text-start">Email</th>
                          </>
                        ) : (
                          <>
                            <th className="text-start">Student ID</th>
                            <th className="text-start">Course ID</th>
                          </>
                        )}
                      </tr>
                    </thead>
                    <tbody>
                      {activeTab === "students" ? (
                        students.length > 0 ? (
                          students.map((student, index) => (
                            <tr key={index}>
                              <td className="text-start">{student.name}</td>
                              <td className="text-start">{student.email}</td>
                            </tr>
                          ))
                        ) : (
                          <tr>
                            <td colSpan="2" className="text-center text-muted">No students added yet</td>
                          </tr>
                        )
                      ) : (
                        enrollments.length > 0 ? (
                          enrollments.map((enrollment, index) => (
                            <tr key={index}>
                              <td className="text-start">{enrollment.studentId}</td>
                              <td className="text-start">{enrollment.courseId}</td>
                            </tr>
                          ))
                        ) : (
                          <tr>
                            <td colSpan="2" className="text-center text-muted">No enrollments added yet</td>
                          </tr>
                        )
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Admin;