const db = require("../config/db");

// Get all courses
const getCourses = (req, res) => {
  const query = "SELECT * FROM courses";
  db.query(query, (err, results) => {
    if (err) {
      return res.status(500).json({ error: "Error fetching courses" });
    }
    res.status(200).json(results);
  });
};

// Add a new course
const addCourse = (req, res) => {
  const { title, description } = req.body;
  const query = "INSERT INTO courses (title, description) VALUES (?, ?)";
  db.query(query, [title, description], (err, result) => {
    if (err) {
      return res.status(500).json({ error: "Error adding course" });
    }
    res.status(201).json({ message: "Course added successfully" });
  });
};

// Update a course
const updateCourse = (req, res) => {
  const { id } = req.params;
  const { title, description } = req.body;
  const query = "UPDATE courses SET title = ?, description = ? WHERE id = ?";
  db.query(query, [title, description, id], (err, result) => {
    if (err) {
      return res.status(500).json({ error: "Error updating course" });
    }
    res.status(200).json({ message: "Course updated successfully" });
  });
};

// Delete a course
const deleteCourse = (req, res) => {
  const { id } = req.params;
  const query = "DELETE FROM courses WHERE id = ?";
  db.query(query, [id], (err, result) => {
    if (err) {
      return res.status(500).json({ error: "Error deleting course" });
    }
    res.status(200).json({ message: "Course deleted successfully" });
  });
};

module.exports = { getCourses, addCourse, updateCourse, deleteCourse };