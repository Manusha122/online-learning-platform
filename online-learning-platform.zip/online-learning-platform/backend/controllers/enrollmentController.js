const db = require("../config/db");

// Enroll a student in a course
const enrollStudent = (req, res) => {
  const { student_id, course_id } = req.body;
  const query = "INSERT INTO enrollments (student_id, course_id) VALUES (?, ?)";
  db.query(query, [student_id, course_id], (err, result) => {
    if (err) {
      return res.status(500).json({ error: "Error enrolling student" });
    }
    res.status(201).json({ message: "Student enrolled successfully" });
  });
};

// Get all enrollments
const getEnrollments = (req, res) => {
  const query = "SELECT * FROM enrollments";
  db.query(query, (err, results) => {
    if (err) {
      return res.status(500).json({ error: "Error fetching enrollments" });
    }
    res.status(200).json(results);
  });
};

module.exports = { enrollStudent, getEnrollments };