const db = require("../config/db");

// Get all students
const getStudents = (req, res) => {
  const query = "SELECT * FROM students";
  db.query(query, (err, results) => {
    if (err) {
      return res.status(500).json({ error: "Error fetching students" });
    }
    res.status(200).json(results);
  });
};

// Add a new student
const addStudent = (req, res) => {
  const { user_id, name, email } = req.body;
  const query = "INSERT INTO students (user_id, name, email) VALUES (?, ?, ?)";
  db.query(query, [user_id, name, email], (err, result) => {
    if (err) {
      return res.status(500).json({ error: "Error adding student" });
    }
    res.status(201).json({ message: "Student added successfully" });
  });
};

// Update a student
const updateStudent = (req, res) => {
  const { id } = req.params;
  const { name, email } = req.body;
  const query = "UPDATE students SET name = ?, email = ? WHERE id = ?";
  db.query(query, [name, email, id], (err, result) => {
    if (err) {
      return res.status(500).json({ error: "Error updating student" });
    }
    res.status(200).json({ message: "Student updated successfully" });
  });
};

// Delete a student
const deleteStudent = (req, res) => {
  const { id } = req.params;
  const query = "DELETE FROM students WHERE id = ?";
  db.query(query, [id], (err, result) => {
    if (err) {
      return res.status(500).json({ error: "Error deleting student" });
    }
    res.status(200).json({ message: "Student deleted successfully" });
  });
};

module.exports = { getStudents, addStudent, updateStudent, deleteStudent };