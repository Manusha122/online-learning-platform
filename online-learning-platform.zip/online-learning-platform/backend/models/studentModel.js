const db = require("../config/db");

const Student = {
  // Get all students
  getAll: (callback) => {
    const query = "SELECT * FROM students";
    db.query(query, callback);
  },

  // Add a new student
  create: (student, callback) => {
    const { user_id, name, email } = student;
    const query = "INSERT INTO students (user_id, name, email) VALUES (?, ?, ?)";
    db.query(query, [user_id, name, email], callback);
  },

  // Update a student
  update: (id, student, callback) => {
    const { name, email } = student;
    const query = "UPDATE students SET name = ?, email = ? WHERE id = ?";
    db.query(query, [name, email, id], callback);
  },

  // Delete a student
  delete: (id, callback) => {
    const query = "DELETE FROM students WHERE id = ?";
    db.query(query, [id], callback);
  },
};

module.exports = Student;