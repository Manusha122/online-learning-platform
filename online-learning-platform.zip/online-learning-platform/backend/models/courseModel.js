const db = require("../config/db");

const Course = {
  // Get all courses
  getAll: (callback) => {
    const query = "SELECT * FROM courses";
    db.query(query, callback);
  },

  // Add a new course
  create: (course, callback) => {
    const { title, description } = course;
    const query = "INSERT INTO courses (title, description) VALUES (?, ?)";
    db.query(query, [title, description], callback);
  },

  // Update a course
  update: (id, course, callback) => {
    const { title, description } = course;
    const query = "UPDATE courses SET title = ?, description = ? WHERE id = ?";
    db.query(query, [title, description, id], callback);
  },

  // Delete a course
  delete: (id, callback) => {
    const query = "DELETE FROM courses WHERE id = ?";
    db.query(query, [id], callback);
  },
};

module.exports = Course;