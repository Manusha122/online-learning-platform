const db = require("../config/db");

const Enrollment = {
  // Get all enrollments
  getAll: (callback) => {
    const query = "SELECT * FROM enrollments";
    db.query(query, callback);
  },

  // Enroll a student in a course
  create: (enrollment, callback) => {
    const { student_id, course_id } = enrollment;
    const query = "INSERT INTO enrollments (student_id, course_id) VALUES (?, ?)";
    db.query(query, [student_id, course_id], callback);
  },
};

module.exports = Enrollment;