const express = require("express");
const Student = require("../models/studentModel");
const authMiddleware = require("../middleware/authMiddleware");

const router = express.Router();

// Get all students
router.get("/", authMiddleware, (req, res) => {
  Student.getAll((err, results) => {
    if (err) {
      return res.status(500).json({ error: "Error fetching students" });
    }
    res.status(200).json(results);
  });
});

// Add a new student
router.post("/", authMiddleware, (req, res) => {
  const student = req.body;
  Student.create(student, (err, result) => {
    if (err) {
      return res.status(500).json({ error: "Error adding student" });
    }
    res.status(201).json({ message: "Student added successfully" });
  });
});

// Update a student
router.put("/:id", authMiddleware, (req, res) => {
  const { id } = req.params;
  const student = req.body;
  Student.update(id, student, (err, result) => {
    if (err) {
      return res.status(500).json({ error: "Error updating student" });
    }
    res.status(200).json({ message: "Student updated successfully" });
  });
});

// Delete a student
router.delete("/:id", authMiddleware, (req, res) => {
  const { id } = req.params;
  Student.delete(id, (err, result) => {
    if (err) {
      return res.status(500).json({ error: "Error deleting student" });
    }
    res.status(200).json({ message: "Student deleted successfully" });
  });
});

module.exports = router;