const express = require("express");
const Enrollment = require("../models/enrollmentModel");
const authMiddleware = require("../middleware/authMiddleware");

const router = express.Router();

// Get all enrollments
router.get("/", authMiddleware, (req, res) => {
  Enrollment.getAll((err, results) => {
    if (err) {
      return res.status(500).json({ error: "Error fetching enrollments" });
    }
    res.status(200).json(results);
  });
});

// Enroll a student in a course
router.post("/", authMiddleware, (req, res) => {
  const enrollment = req.body;
  Enrollment.create(enrollment, (err, result) => {
    if (err) {
      return res.status(500).json({ error: "Error enrolling student" });
    }
    res.status(201).json({ message: "Student enrolled successfully" });
  });
});

module.exports = router;