const express = require("express");
const Course = require("../models/courseModel");
const authMiddleware = require("../middleware/authMiddleware");

const router = express.Router();

// Get all courses
router.get("/", authMiddleware, (req, res) => {
  Course.getAll((err, results) => {
    if (err) {
      return res.status(500).json({ error: "Error fetching courses" });
    }
    res.status(200).json(results);
  });
});

// Add a new course
router.post("/", authMiddleware, (req, res) => {
  const course = req.body;
  Course.create(course, (err, result) => {
    if (err) {
      return res.status(500).json({ error: "Error adding course" });
    }
    res.status(201).json({ message: "Course added successfully" });
  });
});

// Update a course
router.put("/:id", authMiddleware, (req, res) => {
  const { id } = req.params;
  const course = req.body;
  Course.update(id, course, (err, result) => {
    if (err) {
      return res.status(500).json({ error: "Error updating course" });
    }
    res.status(200).json({ message: "Course updated successfully" });
  });
});

// Delete a course
router.delete("/:id", authMiddleware, (req, res) => {
  const { id } = req.params;
  Course.delete(id, (err, result) => {
    if (err) {
      return res.status(500).json({ error: "Error deleting course" });
    }
    res.status(200).json({ message: "Course deleted successfully" });
  });
});

module.exports = router;